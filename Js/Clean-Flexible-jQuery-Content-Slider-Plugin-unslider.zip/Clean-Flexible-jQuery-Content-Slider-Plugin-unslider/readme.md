## Unslider isn't being actively maintained any more, sorry.

If you're after a great feature-rich slider, I recommend [Slick](https://github.com/kenwheeler/slick/) instead; if you're after a small, basic slider, http://basicslider.com/ is fantastic.

Unslider
========

[![Join the chat at https://gitter.im/idiot/unslider](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/idiot/unslider?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

The easiest way to get a simple slider up and running in seconds. All you need
is some valid markup, jQuery and some extra CSS, and Unslider can do the rest.

Check the docs out: http://idiot.github.io/unslider/

Licensed under the [WTFPL](http://www.wtfpl.net).
